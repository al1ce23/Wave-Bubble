
#define SPICLK_PORT PORTC
#define SPIDO_PORT PORTC
#define SPICS_PORT PORTC
#define SPICLK_DDR DDRC
#define SPIDO_DDR DDRC
#define SPICS_DDR DDRC
#define SPICLK 1
#define SPIDO 2
#define SPICS 3


#define BANDWADJ1_RES 1
#define BANDWADJ2_RES 0

#define FREQSET_DDR DDRC
#define FREQSET_PORT PORTC
#define FREQSET 4

#define POWERCTL1_PORT PORTB
#define POWERCTL1 PB7
#define POWERCTL1_DDR DDRB

#define POWERCTL2_PORT PORTD
#define POWERCTL2 PD3
#define POWERCTL2_DDR DDRD

#define LEDDDR DDRD
#define LEDPORT PORTD
#define LED PD7

typedef struct {
	uint16_t startfreq1, endfreq1;  // values for the pot
	uint8_t dc_offset1, bandwidth1;
	uint16_t startfreq2, endfreq2; // values for the PWM
	uint8_t dc_offset2, bandwidth2;
} jammer_setting;

#define CURR_PROG 0x0

void set_freq_high(void);
void set_freq_low(void);
uint8_t set_resistor(uint8_t rnum, uint8_t rval);

void display_programs(void);
