void test_resistors(void);
void test_DC(void);
void test_freq(void);
void test_led(void);
void test_vcos(void);
void test_pll1(void);
void test_pll2_rf(void);
void test_pll2_if(void);
void test_pll3(void);
void test_uart(void);

