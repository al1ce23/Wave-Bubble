#include <avr/io.h>
#include "util.h"
#include "pll.h"
#include "main.h"

void test_uart(void) {
	char c;
	while (1) {
		for (c='a'; c <= 'z'; c++) {
			uart_putchar(c);
			delay_ms(10);
		}
	}
}

void test_led(void) {
	while (1) {
		LEDPORT |= _BV(LED);
		delay_ms(500);
		LEDPORT &= ~_BV(LED);
		delay_ms(500);
	}
}


void test_freq(void) {
	while (1) {
	set_freq_high();
		delay_ms(500);
	set_freq_low();
		delay_ms(500);
	}
}
	
void test_resistors(void) {
	uint8_t i = 0;
	while (1) {
		set_resistor(BANDWADJ1_RES, i);
		set_resistor(BANDWADJ2_RES, 255-i);
		delay_ms(50);
		i++;
	}
}

void test_DC(void) {
	uint8_t i = 0;
	while (1) {
		OCR1A = i;
		OCR1B = 255-i;
		i++;
		delay_ms(50);
	}
}

void test_powerswitch(void) {
	while (1) {
		POWERCTL1_PORT &= ~_BV(POWERCTL1);
		POWERCTL2_PORT |= _BV(POWERCTL2);
		delay_ms(2000);
	
		POWERCTL2_PORT &= ~_BV(POWERCTL2);
		POWERCTL1_PORT |= _BV(POWERCTL1);
		delay_ms(2000);
	}
}

void test_vcos(void) { 
	uint8_t i;
	POWERCTL2_PORT |= _BV(POWERCTL2);
	POWERCTL1_PORT |= _BV(POWERCTL1);
	

	while (1) {
		set_resistor(BANDWADJ1_RES, 0);
		set_resistor(BANDWADJ2_RES, 0);
		for (i = 0; i< 254; i++) {
			OCR1A = i;
			OCR1B = i;
			delay_ms(50);
		}
		
		OCR1A = OCR1B = 127;
		for (i = 0; i< 254; i++) {
			set_resistor(BANDWADJ1_RES, i);
			set_resistor(BANDWADJ2_RES, i);
			delay_ms(50);
		}
	}
	
}

// oscillates pin #10 at 5 Hz
void test_pll1(void) {
	uint32_t out;

	out = 0; out <<= 19; out |= (10&0x7FFF);
	pll_tx(out, 0x0); // no otherbits set: defaults

	while (1) {
		out = 2; out <<= 19; out |= (10&0x7FFF);
		pll_tx(out, 0x3); // no otherbits set: defaults
		delay_ms(100);
		out = 1; out <<= 19; out |= (10&0x7FFF);
		pll_tx(out, 0x3); // no otherbits set: defaults
		delay_ms(100);
	}
}

void test_pll2_rf(void) {
	pll_init();
	
	set_freq_low();
	set_resistor(BANDWADJ1_RES, 0);

	pll_set_rf(2000, 8);
	POWERCTL1_PORT |= _BV(POWERCTL1); // turn on vco

	while (1) {
		OCR1A++; delay_ms(100);
	}
}

void test_pll2_if(void) {
	pll_init();
	
	set_freq_low();
	set_resistor(BANDWADJ2_RES, 0);

	pll_set_if(1200, 8);
	POWERCTL2_PORT |= _BV(POWERCTL2); // turn on vco

	while (1) {
		OCR1B++; delay_ms(50);
	}
}

void step(void) {
	putstring("Step");
	uart_getchar();
	putstring_nl("");
}
