#include <avr/io.h>
#include "pll.h"
#include "util.h"
#include "main.h"

void pll_init(void) {
	uint32_t out;

	ADCSRA = _BV(ADSC) | _BV(ADEN) | _BV(ADPS1) | _BV(ADPS2);

	PLLCLK_DDR |= _BV(PLLCLK);
	PLLDATA_DDR |= _BV(PLLDATA);
	PLLLE_DDR |= _BV(PLLLE);
	PLL_IFIN_DDR &= ~_BV(PLL_IFIN);
	PLL_RFIN_DDR &= ~_BV(PLL_RFIN);
	PLL_IFIN_PORT &= ~_BV(PLL_IFIN);
	PLL_RFIN_PORT &= ~_BV(PLL_RFIN);
	
	pll_tx(0x0, 0x2); // dont use general purpose pins, no fastlock
	pll_tx(0x0, 0x5); // dont use general purpose pins, no fastlock

	// setup 1MHz reference clock
	out = 3; out <<= 19; out |= (10&0x7FFF);
	pll_tx(out, 0x3); // no otherbits set: defaults
	out = 3; out <<= 19; out |= (10&0x7FFF);
	pll_tx(out, 0x0); // no otherbits set: defaults
}

void pll_tx(uint32_t data, uint8_t addr) {
	uint8_t i;
	
	if (addr > 5) return;
	
	data <<= 3;
	data |= (addr & 0x7);
	data <<= 8;
	
	PLLLE_PORT &= ~_BV(PLLLE);
	PLLDATA_PORT &= ~_BV(PLLDATA);
	PLLCLK_PORT &= ~_BV(PLLCLK);

	for (i=0; i<24; i++) {
		PLLCLK_PORT &= ~_BV(PLLCLK);
		if (data & 0x80000000) { 
			PLLDATA_PORT |= _BV(PLLDATA); 
		} else { 
			PLLDATA_PORT &= ~_BV(PLLDATA); 
		}
		NOP;
		PLLCLK_PORT |= _BV(PLLCLK);
		NOP; NOP;
		data <<= 1;	
	}
	PLLLE_PORT |= _BV(PLLLE);
	NOP; NOP; NOP;
	PLLLE_PORT &= ~_BV(PLLLE);
	PLLDATA_PORT &= ~_BV(PLLDATA);
	PLLCLK_PORT &= ~_BV(PLLCLK);
}

void pll_set_rcounter(uint16_t rcounter) {
	pll_tx((rcounter&0x7FFF), 0x0); // no otherbits set: defaults
	pll_tx((rcounter&0x7FFF), 0x3); // no otherbits set: defaults
}


void pll_set_freq(uint16_t rf_freq, uint8_t prescaler, uint8_t reg) {
	uint16_t N;
	uint16_t B, A;
	uint32_t out=0;
	
	if ((prescaler != 8) && (prescaler != 16))
		prescaler = 8;
		
	// Fin = N*fcomp 
	N = rf_freq; // fcomp = 1MHz
	//  N = (P*B) + A
	if (prescaler == 8) {
		B = N / 8;
		A = N % 8;
	} else {
		B = N / 16;
		A = N % 16;
	}
	
	putstring("PLL for RF freq "); putnum_ud(N); 
	putstring("MHz & prescaler "); putnum_ud(prescaler);
	putstring(": B="); putnum_ud(B);
	putstring(" A="); putnum_ud(A);
	putstring_nl("");

	if (prescaler == 16)
		out = 1; // 16 prescale 
	out <<= 15;
	out |= B; out<<= 4;
	out |= A&0xF;
	//putnum_uh(out>> 16);
	//putstring(", ");
	//putnum_uh(out);
	//putstring("\n\r");
	pll_tx(out, reg);
}

uint8_t tune_rf(uint16_t freq) {
	uint8_t i, low, high;
	
	pll_set_rf(freq, 8);

	set_resistor(BANDWADJ1_RES, 0);
	POWERCTL1_PORT |= _BV(POWERCTL1); // turn on vco

	OCR1A = 5; delay_ms(1000);
	if (PLL_RFIN_PIN & _BV(PLL_RFIN)) {	// we cant tune any lower...???
		putstring_nl("RF VCO range is too high!");
		while (1);
		return 0;
	}
	putstring_nl("");
	OCR1A = 255; 
	/*for (i=0; i<250; i++) {
		putnum_ud(PLL_IFIN_PIN & _BV(PLL_IFIN));
		uart_putchar(' ');
	}*/
	delay_ms(1000);
	//step();
	if (! (PLL_RFIN_PIN & _BV(PLL_RFIN))) {	// we cant tune any higher...???
		putstring_nl("RF VCO range is too low!");
		while (1);
		return 0;
	}
	
	putstring("midpoint @");
	low = 0;
	high = 255;
	while ((low + 2) <= high) {
		//putnum_ud(low); uart_putchar('/'); putnum_ud(high); uart_putchar('\t');
		i = ((uint16_t)low+(uint16_t)high)/2;
		OCR1A = i;
		//putnum_ud(OCR1A); putstring(", ");
		delay_ms(100);
		if (PLL_RFIN_PIN & _BV(PLL_RFIN)) {
			delay_ms(1);
			if (PLL_RFIN_PIN & _BV(PLL_RFIN)) {
				high = i;
			}
		} else {
			low = i;
		}
	}
	putnum_ud(i); putstring_nl("");
	return i;
}

void read_if_pin(void) {
	uint8_t i;
	uint16_t avg, t;
	
	ADMUX = 5;
	for (i=0; i<250; i++) {
		putnum_ud(PLL_IFIN_PIN & _BV(PLL_IFIN));
		uart_putchar(' ');
		ADCSRA |=  _BV(ADSC);
		while (ADCSRA & _BV(ADSC)); // wait for conversion to finish;
		t = ADC;
		putnum_ud(t);
		uart_putchar(' ');
	}
	avg += t;
}

uint8_t tune_if(uint16_t freq) {
	uint8_t i, low, high;
	
	pll_set_if(freq, 8);

	set_resistor(BANDWADJ2_RES, 0);
	POWERCTL2_PORT |= _BV(POWERCTL2); // turn on vco

	OCR1B = 5; 
	delay_ms(1000);
	//read_if_pin(); step();
	if (PLL_IFIN_PIN & _BV(PLL_IFIN)) {	// we cant tune any lower...???
		putstring_nl("IF VCO range is too high!");
		return 0;
	}
	
	OCR1B = 255;	delay_ms(1000);

	//read_if_pin(); step();
	if (! (PLL_IFIN_PIN & _BV(PLL_IFIN))) {	// we cant tune any higher...???
		putstring_nl("IF VCO range is too low!");
		return 0;
	}
	
	putstring("midpoint @");
	low = 0;
	high = 255;
	while ((low + 2) <= high) {
		i = ((uint16_t)low+(uint16_t)high)/2;
		OCR1B = i;
		//putnum_ud(OCR1B); putstring(", ");
		delay_ms(100);
		if (PLL_IFIN_PIN & _BV(PLL_IFIN)) {
			delay_ms(1);
			if (PLL_IFIN_PIN & _BV(PLL_IFIN)) {
				high = i;
			}
		} else {
			low = i;
		}
	}
	putnum_ud(i); putstring_nl("");
	return i;
}

uint8_t tune_rf_band(uint16_t min, uint16_t max, uint8_t vco_num) {
	uint16_t t, threshhold;
	uint32_t avg;
	uint8_t i, j, low, high, midpt;
	
	if (min > max) {
		t = max;
		max = min;
		min = t;
	}
	
	if (vco_num == 0)
		midpt = tune_rf((min+max)/2);
	else
		midpt = tune_if((min+max)/2);
	
	if (midpt == 0) // start in the middle
		return 0;
	
	putstring_nl("\n\rbandwidth tuning...");
	if (vco_num==0)
		pll_set_rf(min, 8)
	else 
		pll_set_if(min, 8);
	set_freq_low();

	// get high vals?
	if (vco_num == 0) {
		set_resistor(BANDWADJ1_RES, 0);
		ADMUX = 0;
	} else {
		set_resistor(BANDWADJ2_RES, 0);
		ADMUX = 5;
	}
	delay_ms(100);
	avg = 0;
	for (j = 0; j < 127; j++) {
		ADCSRA |=  _BV(ADSC);
		while (ADCSRA & _BV(ADSC)); // wait for conversion to finish;
		t = ADC;
		avg += t;
		//putnum_ud(t); uart_putchar(' ');
	}
	avg /= 128;
	//putstring("max = "); putnum_ud(avg); putstring_nl("");
	threshhold = avg;

	low = 0;
	high = 255;
	while ((low + 2) <= high) {
		i = ((uint16_t)low+(uint16_t)high)/2;
		// set the bandwidth
		if (vco_num == 0)
			set_resistor(BANDWADJ1_RES, i);
		else
			set_resistor(BANDWADJ2_RES, i);
		//putnum_ud(i); putstring(", ");
		delay_ms(1000);
		
		// read ADC
		
		if (vco_num == 0)
			ADMUX = 0;
		else
			ADMUX = 5;
		
		avg = 0;
		for (j = 0; j < 127; j++) {
			ADCSRA |=  _BV(ADSC);
			while (ADCSRA & _BV(ADSC)); // wait for conversion to finish;
			t = ADC;
			avg += t;
			//putnum_ud(t); uart_putchar(' ');
		}
		avg /= 128;
		//putnum_ud(avg); putstring_nl("");
		if (avg < (threshhold-10)) {
			high = i;
		} else {
			low = i;
		}
	}
	putnum_ud(i);
	putstring_nl(" done!");
	set_freq_high();
	return i;
}

uint8_t tune_if_band(uint16_t min, uint16_t max) {
	uint16_t t;
	uint8_t i, low, high, midpt;
	
	if (min > max) {
		t = max;
		max = min;
		min = t;
	}
	
	set_freq_low();

	midpt = tune_if((min+max)/2);
	if (midpt == 0) // start in the middle
		return 0;
	
	putstring("\n\rbandwidth tune...");
	pll_set_if(min, 8);
	low = 0;
	high = 255;
	while ((low + 2) <= high) {
		i = ((uint16_t)low+(uint16_t)high)/2;
		// set the bandwidth
		set_resistor(BANDWADJ2_RES, i);
		putnum_ud(i); putstring(", ");
		delay_ms(100);
		if (PLL_IFIN_PIN & _BV(PLL_IFIN)) {
			low = i;
		} else {
			high = i;
		}
	}
	putstring_nl("done!");
	set_freq_high();
	return i;
}

