#include <avr/io.h>
#include <avr/eeprom.h>
#include <avr/interrupt.h>
#include "util.h"
#include "main.h"
#include "pll.h"
#include "test.h"

#define BRR_19200 26

uint8_t EEMEM max_programs=0, curr_program=0;

jammer_setting EEMEM *settings_ee;

SIGNAL (SIG_COMPARATOR) {
/*
	if (ACSR & _BV(ACO)) {
		LEDPORT |= _BV(LED);
	} else {
		LEDPORT &= ~_BV(LED);	
	}
*/
}


void init_varres(void) {
  SPICS_DDR |= _BV(SPICS);
  SPIDO_DDR |= _BV(SPIDO);
  SPICLK_DDR |= _BV(SPICLK);

  SPICS_PORT |= _BV(SPICS);
  SPICLK_PORT &= ~_BV(SPICLK);

}

uint8_t set_resistor(uint8_t rnum, uint8_t rval) {
  uint16_t d;
  
  d = rnum;
  d <<= 8;
  d |= rval;

  SPICS_PORT &= ~_BV(SPICS);
  NOP; NOP; NOP; NOP;

  for (rnum=0; rnum < 10; rnum++) {
    if (d & 0x200) {
      SPIDO_PORT |= _BV(SPIDO);
    } else {
      SPIDO_PORT &= ~_BV(SPIDO);
    }
    SPICLK_PORT |= _BV(SPICLK);    
    NOP; NOP; NOP;
    NOP; NOP; NOP;
    SPICLK_PORT &= ~_BV(SPICLK); 
    d <<= 1;
  }
  NOP; NOP; NOP; NOP;
  SPICS_PORT |= _BV(SPICS);

  return 0;
}


void set_freq_high(void) {
	// set the pin to be a high output
	FREQSET_DDR |= _BV(FREQSET);
	FREQSET_PORT |= _BV(FREQSET);
}

void set_freq_low(void) {
	// set the pin to be a high input
	FREQSET_DDR &= ~_BV(FREQSET);
	FREQSET_PORT |= _BV(FREQSET);
}

void init_pwm(void) {
  DDRB |= _BV(PB1);  // make OCR1A it an output
  DDRB |= _BV(PB2);  // make OCR1B it an output
  
  TCCR1A = _BV(COM1A1) | _BV(COM1B1) | _BV(WGM12) | _BV(WGM10); // 8-10bit?
  TCCR1B = _BV(CS10);
  OCR1A = 0x0;  // change this value to adjust PWM.
  OCR1B = 0x0;  // change this value to adjust PWM.
}



void print_menu(void) {
	print_div();
	putstring_nl(" p> Display progs");
	putstring_nl(" a> Add prog");
	putstring_nl(" d> Delete prog");
	putstring_nl(" t> Tune prog");
	putstring_nl(" q> Quit");
	print_div();
    putstring("=> ");
}

void print_program(jammer_setting *setting, uint8_t n, uint8_t m) {
	print_div();
	putstring("Program #"); putnum_ud(n+1);
	putstring(" of "); 
	putnum_ud(m); putstring_nl("");

	putstring("\n\rVCO 1: "); 
	putnum_ud(setting->startfreq1);
	putstring(" -> ");
	putnum_ud(setting->endfreq1);
	putstring(" ("); putnum_ud(setting->dc_offset1);
	putstring(", "); putnum_ud(setting->bandwidth1);
	putstring(")\n\rVCO 2: "); 
	putnum_ud(setting->startfreq2);
	putstring(" -> ");
	putnum_ud(setting->endfreq2);
	putstring(" ("); putnum_ud(setting->dc_offset2);
	putstring(", "); putnum_ud(setting->bandwidth2);
	putstring_nl(")");
}

void delete_program(void) {
	uint8_t n, max;
	
	display_programs();
	print_div();
	putstring("Delete #? ");
	n = uart_read16();
	max = eeprom_read_byte(&max_programs);
	if (n > max) {
		putstring_nl("\n\rInvalid");
	} else {
		if (n == max) {
			// easy, just reduce #
			eeprom_write_byte(&max_programs, max-1);
		} else {
			//ugh
		}
	}
}


void tune_it (uint8_t n, uint8_t save) {

	jammer_setting setting;

		eeprom_read_block(&setting, 
			&settings_ee+sizeof(jammer_setting)*n,
			sizeof(jammer_setting));
		if ((setting.startfreq1 != 0) && (setting.endfreq1 != 0)) {
			setting.bandwidth1 = tune_rf_band(setting.startfreq1, setting.endfreq1, 0);
			setting.dc_offset1 = OCR1A;
		}	
		if ((setting.startfreq2 != 0) && (setting.endfreq2 != 0)) {
			setting.bandwidth2 = tune_rf_band(setting.startfreq2, setting.endfreq2, 1);
			setting.dc_offset2 = OCR1B;
		}
		if (save) {
			eeprom_write_block(&setting, 
				&settings_ee+sizeof(jammer_setting)*n,
				sizeof(jammer_setting));
		}
}


void tune_program(void) {
	uint8_t n;
	
	display_programs();
	print_div();
	putstring("Tune prog # ");
	n = uart_read16();
	if (n > eeprom_read_byte(&max_programs)) {
		putstring_nl("\n\rInvalid #");
	} else {
		tune_it(n-1, 1);
	}
}
void display_programs(void) {
	uint8_t i, progs;
	jammer_setting setting;

	progs = eeprom_read_byte(&max_programs);
	putnum_ud(progs); putstring (" programs in memory\n\r");
	for (i=0; i< progs; i++) {
		eeprom_read_block(&setting, 
			&settings_ee+sizeof(jammer_setting)*i,
			sizeof(jammer_setting));
			print_program(&setting, i, progs);
	}
}

void add_program(void) {
	jammer_setting new_setting;
	uint8_t progs;
	
	putstring("VCO1 start: ");
	new_setting.startfreq1 = uart_read16();
	putstring("\n\rend: ");
	new_setting.endfreq1 = uart_read16();
	putstring("\n\rVCO2 start: ");
	new_setting.startfreq2 = uart_read16();
	putstring("\n\rend: ");
	new_setting.endfreq2 = uart_read16();
	new_setting.dc_offset1 = new_setting.dc_offset2 = 0;
	new_setting.bandwidth1 = new_setting.bandwidth2 = 0;
	
//	display_programs();

	progs = eeprom_read_byte(&max_programs);
	eeprom_write_block(&new_setting, 
		&settings_ee+sizeof(jammer_setting)*progs, 
		sizeof(jammer_setting));
	eeprom_write_byte(&max_programs, progs+1);
	putstring_nl("");
}

void run_menu(void) {
	char c;
	
	do {
		print_menu();
		c = uart_getchar();
		uart_putchar(c);
		putstring_nl("");
		switch (c) {
			case 'p':
				display_programs();
				break;
			case 'a':
				add_program();
				break;
			case 'd':
				delete_program();
				break;
			case 't':
				tune_program();
				break;
			case 'q': break;
			default:
				putstring_nl("Bad command");
		}
	} while (c != 'q');

}

int main(void) {
	uint8_t i=0, progs;
	int programnum;
	jammer_setting setting;
	
	LEDDDR |= _BV(LED);

	//test_freq();    // alternate high/low sawtooth
	//test_led();   // test the LED only
    
	POWERCTL1_DDR |= _BV(POWERCTL1);
	POWERCTL2_DDR |= _BV(POWERCTL2);
	POWERCTL1_PORT &= ~_BV(POWERCTL1); // turn off vcos/gain
	POWERCTL2_PORT &= ~_BV(POWERCTL2); // turn off vcos/gain
 	
	// initialize serial port
	uart_init(BRR_19200);

	// turn on bandgap ref, the comparator and allow an interrupt
	//ACSR = _BV(ACBG) | _BV(ACIE);
	//DIDR1 = _BV(AIN1D);
	//sei();
	
	set_freq_high();
	init_varres();
	init_pwm();
	pll_init();

	//test_resistors();      // test the digital potentiometers
	//test_DC();             // sweep DC offset (PWM)
	//test_powerswitch();    // turn power switches on & off
	//test_vcos();           // test VCOs: sweep and bandwidth
	//test_pll1();           // simple crystal/function test
	//test_uart();
	
	putnum_uh(MCUSR);
	MCUSR = 0;
	putstring_nl("Wavebubble v1.0");

	//test_pll2_rf();				// test PLL response to high VCO
	test_pll2_if();				// test PLL response to low VCO
	
	progs = eeprom_read_byte(&max_programs);
	if  (progs != 0) {
		putstring("keypress..");	
		delay_ms(1500);
	}
	if (uart_getch() && (uart_getchar() == 0x20)) {
		putstring_nl("");
		run_menu();
	} else if (progs == 0)
		run_menu();
	
	progs = eeprom_read_byte(&max_programs);
	programnum = eeprom_read_byte(&curr_program);
	if (programnum >= progs)
		programnum = 0;

	eeprom_read_block(&setting, 
			&settings_ee+sizeof(jammer_setting)*programnum,
			sizeof(jammer_setting));
	putstring_nl("");
	print_program(&setting, programnum, progs);
	eeprom_write_byte(&curr_program, programnum+1);
			
	// blink to show the program;
	for (i = 0; i < programnum; i++) {
		LEDPORT |= _BV(LED);
		delay_ms(100);
		LEDPORT &= ~_BV(LED);
		delay_ms(100);
	}

	print_div();	
	
	if ((setting.dc_offset1 == 0) && (setting.bandwidth1 == 0) &&
		(setting.dc_offset2 == 0) && (setting.bandwidth2 == 0)) {
			tune_it(programnum, 0); // meme check return
	} else {
		if (setting.startfreq1 != 0) {
			OCR1A = setting.dc_offset1;
			set_resistor(BANDWADJ1_RES, setting.bandwidth1);
			POWERCTL1_PORT |= _BV(POWERCTL1); // turn on vcos/gain
		}
		if (setting.startfreq2 != 0) {
			OCR1B = setting.dc_offset2;
			set_resistor(BANDWADJ2_RES, setting.bandwidth2);
			POWERCTL2_PORT |= _BV(POWERCTL2); // turn on vcos/gain
		}
	}
	
	print_div();
	
	while (1) {
		LEDPORT |= _BV(LED);
		delay_ms(100);
		LEDPORT &= ~_BV(LED);
		delay_ms(900);
	}
	
}
