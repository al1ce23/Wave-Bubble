#include <avr/io.h>
#include <avr/interrupt.h>
#include "util.h"

/*
uint8_t internal_eeprom_read(uint16_t addr) {
  loop_until_bit_is_clear(EECR, EEPE); // wait for last write to finish
  EEAR = addr;
  EECR |= _BV(EERE);        // start EEPROM read
  return EEDR;            // takes only 1 cycle
}

void internal_eeprom_write(uint16_t addr, uint8_t data) {
  loop_until_bit_is_clear(EECR, EEPE); // wait for last write to finish
  EEAR = addr;
  EEDR = data;
  cli();                // turn off interrupts 
  EECR |= _BV(EEMPE);     // these instructions must happen within 4 cycles
  EECR |= _BV(EEPE);
  sei();                // turn on interrupts again
}
*/

 void delay_ms(uint16_t ms) {
  uint16_t delay_count = F_CPU / 17500;
  volatile uint16_t i;

  while (ms != 0) {
    for (i=0; i != delay_count; i++);
    ms--;
  }
}

void uart_init(uint16_t brr) {
	UBRR0 = brr;
	UCSR0B = _BV(RXEN0) | _BV(TXEN0);
	UCSR0C = _BV(USBS0) | (3<<UCSZ00);
	DDRD |= _BV(PD1);
	DDRD &= ~_BV(PD0);
}

void uart_putchar(char c) {
	while (!(UCSR0A & _BV(UDRE0)));
	UDR0 = c;
}
char uart_getchar(void) {
	while (!(UCSR0A & _BV(RXC0)));
	return UDR0;
}

char uart_getch(void) {
	return (UCSR0A & _BV(RXC0));
}

uint16_t uart_read16(void) {
	uint8_t c;
	uint16_t t=0;
	while ( (c = uart_getchar()) != '\n') {
		if (c == '\r') break;
		if ((c  > '9') || (c < '0'))
			continue;
		uart_putchar(c);
		t *= 10;
		t += c-'0';
	}
	uart_putchar(c);
	return t;
}
void ROM_putstring(const char *str, uint8_t nl) {
	uint8_t i;

	for (i=0; pgm_read_byte(&str[i]); i++) {
		uart_putchar(pgm_read_byte(&str[i]));
  }
  if (nl) {
		uart_putchar('\n'); uart_putchar('\r');
  }
}
/*
void RAM_putstring(char *str, uint8_t nl) {
	uint8_t i;

	for (i=0; str[i]; i++) {
		uart_putchar(str[i]);
  }
}
*/

void printhex(uint8_t hex) {
  hex &= 0xF;
  if (hex < 10)
    uart_putchar(hex + '0');
  else
    uart_putchar(hex + 'A' - 10);
}

void putnum_uh(uint16_t n) {
  if (n >> 12)
    printhex(n>>12);
  if (n >> 8)
    printhex(n >> 8);
  if (n >> 4)
    printhex(n >> 4);
  printhex(n);

  return;
}


void putnum_ud(uint16_t n) {
	uint8_t cnt=0, flag=0;
	
	while (n >= 10000UL) { flag = 1; cnt++; n -= 10000UL; }
	if (flag) uart_putchar('0'+cnt); 
	cnt = 0;
	while (n >= 1000UL) { flag = 1; cnt++; n -= 1000UL; }
	if (flag) uart_putchar('0'+cnt); 
	cnt = 0;
	while (n >= 100UL) { flag = 1; cnt++; n -= 100UL; }
	if (flag) uart_putchar('0'+cnt); 
	cnt = 0;
	while (n >= 10UL) { flag = 1; cnt++; n -= 10UL; }
	if (flag) uart_putchar('0'+cnt); 
	cnt = 0;
	uart_putchar('0'+n); 
	return;
}

void print_div(void) {
	putstring_nl("---------------------------------");
};
